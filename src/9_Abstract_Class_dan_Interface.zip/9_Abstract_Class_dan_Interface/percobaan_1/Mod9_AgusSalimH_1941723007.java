/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mod9_agussalimh_1941723007;

/**
 *
 * @author rian
 */
public class Mod9_AgusSalimH_1941723007 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        AgusSalimH_1941723007Kucing kucingKampung = new AgusSalimH_1941723007Kucing();
        IkanAgusSalimH_1941723007 lumbaLumba = new IkanAgusSalimH_1941723007();
        
        OrangAgusSalimH_1941723007 ani = new OrangAgusSalimH_1941723007("Ani");
        OrangAgusSalimH_1941723007 budi = new OrangAgusSalimH_1941723007("Budi");
        
        ani.peliharaHewanAgusSalimH_1941723007(kucingKampung);
        budi.peliharaHewanAgusSalimH_1941723007(lumbaLumba);
        
        ani.ajakPeliharaanJalanJalanAgusSalimH_1941723007();
        budi.ajakPeliharaanJalanJalanAgusSalimH_1941723007();
    }
    
}
