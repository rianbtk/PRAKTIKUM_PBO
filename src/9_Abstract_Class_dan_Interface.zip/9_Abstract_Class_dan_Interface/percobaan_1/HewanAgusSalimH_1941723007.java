/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mod9_agussalimh_1941723007;

/**
 *
 * @author rian
 */
public abstract class HewanAgusSalimH_1941723007 {
    private int umur;
    protected HewanAgusSalimH_1941723007(){
        this.umur = 0;
    }
    public void bertambahUmurAgusSalimH_1941723007(){
        this.umur +=1;
    }
    public abstract void bergerakAgusSalimH_1941723007();
    
}
