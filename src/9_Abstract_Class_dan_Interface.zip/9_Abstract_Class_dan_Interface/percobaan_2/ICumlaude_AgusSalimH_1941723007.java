/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mod9_agussalimh_1941723007.per2;

/**
 *
 * @author rian
 */
public interface ICumlaude_AgusSalimH_1941723007 {
    public abstract void lulus_AgusSalimH_1941723007();
    public abstract void meraihIPKTertinggi_AgusSalimH_1941723007();
}
